fixture subset of gstack at the pinned revision
